package CustomComponents;

public interface FancyGifDialogListener {
    void OnClick();
}