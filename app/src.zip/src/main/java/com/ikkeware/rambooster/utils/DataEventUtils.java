package com.ikkeware.rambooster.utils;

public interface DataEventUtils {
    void onItemDeleted();
}
