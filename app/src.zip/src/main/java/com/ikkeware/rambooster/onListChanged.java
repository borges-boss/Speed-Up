package com.ikkeware.rambooster;

public interface onListChanged
{
public void onListItemsChanged();

public void onContentFinishLoading();

}


